#include <iostream>
#include <cstdlib>
#include <string>
#include <sstream>
using namespace std;

//#define PRAC8_1
//#define PRAC8_2
#define PRAC8_3

class Node{
private:
  string str;
  Node* next;
public:
  Node(string s, Node* n){
    str = s;
    next = n;
  }
  friend class Stack;
};

class Stack{
private:
  Node* head;
	
public:
  Stack(){head = NULL;}
  ~Stack(){while(!isEmpty())pop();}
  void push(string);
  string pop();
  bool isEmpty(){return head == NULL;}	
};

void Stack::push(string s){
  Node* newHead = new Node(s, head);
  head = newHead;
}

string Stack::pop(){
  if(head == NULL){
    cerr << "StackError : error can't pop " << endl;
  }
  string ret = head->str;
  Node* ptr = head->next;
  delete head;
  head = ptr;
  return ret;
}

#ifdef PRAC8_1
int main(){
  Stack stk;
  string str;
  cout << "Input Strings:";
  while(cin >> str){
    stk.push(str);
  }
  cout << endl;
  while(!stk.isEmpty()){
    cout << stk.pop() << " ";
  }
  cout << endl;
  return 0;
}
#endif

#ifdef PRAC8_2

bool isOperatorStr(string str){
	return str == "+" || str == "-" || str == "*" || str == "/";
}

double calcWithStringOperator(string str, double operand1, double operand2){
  double result;
  
  if(str == "+") result = operand1 + operand2;
  else if(str == "-") result = operand1 - operand2;
  else if(str == "*") result = operand1 * operand2;
  else if(str == "/") result = operand1 / operand2;
  else{
    cerr << "operatorString argument is not correct string" << endl;
    exit(EXIT_FAILURE);
  }
  return result;
}

int main(){
  Stack porland;
  cout << "Input Formula:";
  string inputStr;
  while(cin >> inputStr){
    if(inputStr == "$") break;
    if(isOperatorStr(inputStr)){
      double operand1 = atoi(porland.pop().c_str());
      double operand2 = atoi(porland.pop().c_str());
      double result = calcWithStringOperator(inputStr, operand2, operand1);

      stringstream ss;
      ss << result;
      inputStr = ss.str();
      //cout << "result : " << result << "   str : "<< inputStr << endl;
    }
    porland.push(inputStr);
  }
  cout << endl;
  cout << " =  " << porland.pop() << endl;
  return 0;
}
#endif

#ifdef PRAC8_3
bool isStartBracket(const char& c){
  return c == '(' || c == '[' || c == '{';
}

bool isEndBracket(const char& c){
  return c == ')' || c == ']' || c == '}';
}

bool isBracket(const char& c){
  return isStartBracket(c) || isEndBracket(c);
}

bool isSameKindBracket(const char& b1, const char& b2){
  bool result = false;
  if(b1 == '(' && b2 == ')') result = true;
  if(b1 == ')' && b2 == '(') result = true;
  if(b1 == '{' && b2 == '}') result = true;
  if(b1 == '}' && b2 == '{') result = true;
  if(b1 == '[' && b2 == ']') result = true;
  if(b1 == ']' && b2 == '[') result = true;
  return result;
}

int main(){
  Stack bracketStack;
  cout << "Input Code:";
  string codeString;
  while(cin >> codeString){
    //文字に分解して格好括弧のみスタックに追加
    for(int i = 0; i < codeString.length(); i++){
      char c = codeString[i];
      string char_string(1,codeString[i]);
      //if endbracket ,then pop
      if(isStartBracket(c)) bracketStack.push(char_string);
      if(isEndBracket(c)){
	string preBracket = bracketStack.pop();
	if(!isSameKindBracket(c, preBracket.c_str()[0])){
	  cout << c << " " << preBracket.c_str()[0] << endl;
	  cout << "bad!" << endl;
	  return 0;
	}
      }
    }
  }
  cout << endl;
  cout << "good!" << endl;
  return 0;
}
#endif
