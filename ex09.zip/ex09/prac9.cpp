#include <iostream>
#include <cstdlib>
#include <iomanip>

using namespace std;

//#define PRAC9_1
#define PRAC9_2
//#define _DEBUG

//Point
class Point{
private:
  int x, y;
public:
  Point(int _x = -1, int _y = -1){
    x = _x;
    y = _y;
  }
  int getX(){
    return x;
  }
  int getY(){
    return y;
  }
  
};

ostream& operator<<(ostream& stream, Point p){
  stream << "(" << p.getX() << ", " << p.getY() << ")";
  return stream;
}

//Node
class Node{
private:
  Point data;
  Node* next;
public:
  Node(Point p, Node* n){
    data = p;
    next = n;
  }
  //accessor
  Node* getNext(){return next;}
  void setNext(Node* np){next = np;}
  Point getData(){return data;}
};

class Queue{
private:
  Node* front;
  Node* rear;

public:
  Queue(){front = rear = NULL;}
  ~Queue();
  void enqueue(Point);
  Point dequeue();
  bool isEmpty();
};
//destructor
//member functions

void Queue::enqueue(Point p){
  //新しいノードを作成
  //リアに追加し、リアを更新
  Node* newNode = new Node(p, NULL);
  bool emptyFlag = isEmpty();
  if(emptyFlag)front = newNode;
  if(!emptyFlag)rear->setNext(newNode);
  rear = newNode;
  #ifdef _DEBUG
  cout << "enqueue : " << newNode << " next : " << newNode->getNext() << endl;
  #endif
}

Point Queue::dequeue(){
  //先頭からデータを吐き出し
  //ノードを削除
  //先頭を更新
  if(isEmpty()){
    cerr << "Error : front is NULL. can't dequeu" << endl;
    exit(EXIT_FAILURE);
  }
  Point data = front->getData();
  Node* tmp = front;
  front = front->getNext();
  #ifdef _DEBUG
  cout << "dequeue : " << tmp << endl;
  cout << "front   : " << front << endl;
  #endif
  delete tmp;
  return data;
}

bool Queue::isEmpty(){
  return front == NULL;
}

Queue::~Queue(){
  while(!isEmpty())
    dequeue();
}


#ifdef PRAC9_1
int main(){
  Queue q;
  int x, y;
  
  cout << "Input Position : " << endl;
  
  //input
  while(cin >> x >> y)
    q.enqueue(Point(x,y));
  cout << endl;

  //output
  while(!q.isEmpty())
    cout << q.dequeue() << " ";
  cout << endl; 

  return 0;
}
#endif


#ifdef PRAC9_2

#define N 5

//debug function
#ifdef _DEBUG
void printArray(int arr[N][N]){
  for(int i = 0; i < N; i++){
    
    for(int j = 0; j < N; j++){
      cout << setw(2) << arr[i][j];
    }
    cout << endl;
  }
  cout << endl;
}
#endif

bool simulate(int arr[N][N]){
    // Step1: 空のキューを用意する
    Queue q;
    // Step2: すべての初期燃焼点をキューに追加する（補完する）
    for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            // 未発火点をキューに追加
	  if(arr[i][j] == 1){
	    #ifdef _DEBUG
	    cout << "burning (" << i << ", " << j << ")" << endl;
	    #endif
	    q.enqueue(Point(i,j));
	  }
        }
    }
    // Step3: 燃焼シミュレーションを行う（補完する    //return NULL;）
    while(!q.isEmpty()){
      #ifdef _DEBUG
      cout << "dequeue and check neighbor" << endl;
      #endif
      Point index = q.dequeue();
      
      //近傍をの座標を配列に格納
      const int neighborNum = 4;
      Point neighbor[neighborNum] = {
	Point(index.getX()    , index.getY() + 1),
	Point(index.getX()    , index.getY() - 1),
	Point(index.getX() + 1, index.getY()),
	Point(index.getX() - 1, index.getY())
      };
      //各近傍の燃焼
      for(int i = 0; i < neighborNum; i++){
	if(neighbor[i].getX() < 0 || neighbor[i].getX() > N-1) continue;
	if(neighbor[i].getY() < 0 || neighbor[i].getY() > N-1) continue;     
	if(arr[neighbor[i].getX()][neighbor[i].getY()] == 0){
	  #ifdef _DEBUG
	  cout << "able ot burn (" << neighbor[i] << endl;
	  #endif
	  arr[neighbor[i].getX()][neighbor[i].getY()] = 1;
	  q.enqueue(neighbor[i]);
	}
      }
      #ifdef _DEBUG
      printArray(arr);
      #endif
    }
    #ifdef _DEBUG
    cout << "start step4" << endl;
    #endif
    // Step4: 燃焼可能な点まだ残っているかを確認し，結果を返す
    for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            // 未発火点がまだ残っている場合，falseを返す．
            if(arr[i][j] == 0)
                return false;
        }
    }
    return true;
}

int main(){
	int ins1[N][N] = {
		{1, 0,-1, 0, 0},
		{0,-1, 1, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0,-1, 0},
		{0, 0,-1, 0, 0}};
	bool rst = simulate(ins1);
	if(rst)
		cout << "ins1は完全燃焼できた" << endl;
	else
		cout << "ins1は燃えきらなかった" << endl;
	int ins2[N][N] = {
		{0, 0,-1, 0, 0},
		{0,-1, 0,-1, 0},
		{0, 0,-1, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0,-1, 1, 0}};
	rst = simulate(ins2);
	if(rst)
		cout << "ins2は完全燃焼できた" << endl;
	else
		cout << "ins2は燃えきらなかった" << endl;
    return 0;
}
#endif
